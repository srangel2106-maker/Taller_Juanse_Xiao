import Banner from './components/Banner'
import Card from './components/Card'
import Libre from './components/Libre'

function App() {
  return (
    <div className="min-h-screen bg-teal-950 text-white">
      <Banner
        titulo="Xiao, el Yaksha de Liyue"
        subtitulo="Conquistador de Demonios que protege Liyue desde las sombras con su lanza y el poder del viento."
        boton="Conocer más"
      />

      <section id="personajes" className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="mb-8 text-center text-3xl font-bold">Mundo de Xiao</h2>
        <div className="grid gap-6 md:grid-cols-3">
          <Card
            imagen="/images/Xiao.jpg"
            etiqueta="Personaje"
            titulo="Xiao"
            descripcion="Adepto de Liyue que usa una lanza y el elemento Anemo."
          />
          <Card
            imagen="/images/Liyue.jpg"
            etiqueta="Región"
            titulo="Puerto de Liyue"
            descripcion="La ciudad que Xiao ha protegido durante siglos."
          />
          <Card
            imagen="/images/lanza.jpg"
            etiqueta="Arma"
            titulo="Lanza"
            descripcion="El arma con la que Xiao derrota a los demonios."
          />
        </div>
      </section>

      <Libre />

      <footer className="py-6 text-center text-sm text-teal-300">
        Parcial · React + Vite + Tailwind · Temática Xiao
      </footer>
    </div>
  )
}

export default App
