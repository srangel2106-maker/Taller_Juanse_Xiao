function Card({ imagen, titulo, descripcion, etiqueta }) {
  return (
    <article className="overflow-hidden rounded-2xl border border-teal-700 bg-teal-900 shadow-lg transition hover:-translate-y-1 hover:shadow-emerald-500/30">
      <img src={imagen} alt={titulo} className="h-48 w-full object-cover" />
      <div className="p-5">
        <span className="rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-teal-950">
          {etiqueta}
        </span>
        <h3 className="mt-3 text-xl font-bold text-white">{titulo}</h3>
        <p className="mt-2 text-sm text-teal-100">{descripcion}</p>
      </div>
    </article>
  )
}

export default Card
