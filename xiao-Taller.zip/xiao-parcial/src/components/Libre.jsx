import { useState } from 'react'

const habilidades = {
  normal: {
    nombre: 'Ataque normal',
    detalle: 'Xiao ataca con su lanza en una serie rápida de estocadas.',
  },
  skill: {
    nombre: 'Habilidad elemental',
    detalle: 'Se lanza hacia adelante con el viento, dañando a los enemigos en su camino.',
  },
  burst: {
    nombre: 'Habilidad definitiva',
    detalle: 'Adopta su forma de Yaksha: más daño y saltos más altos mientras dura.',
  },
}

function Libre() {
  const [activa, setActiva] = useState('normal')

  return (
    <section className="mx-auto max-w-3xl px-6 py-16">
      <h2 className="mb-6 text-center text-3xl font-bold text-white">Habilidades de Xiao</h2>

      <div className="mb-6 flex justify-center gap-3">
        {Object.keys(habilidades).map((clave) => (
          <button
            key={clave}
            onClick={() => setActiva(clave)}
            className={
              'rounded-full px-5 py-2 font-semibold transition ' +
              (activa === clave
                ? 'bg-amber-400 text-teal-950'
                : 'bg-teal-800 text-teal-100 hover:bg-teal-700')
            }
          >
            {habilidades[clave].nombre}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border-2 border-amber-400 bg-teal-900 p-8 text-center shadow-xl">
        <h3 className="text-2xl font-bold text-amber-300">{habilidades[activa].nombre}</h3>
        <p className="mt-3 text-lg text-teal-100">{habilidades[activa].detalle}</p>
      </div>
    </section>
  )
}

export default Libre
