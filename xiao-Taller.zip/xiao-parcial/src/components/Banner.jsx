function Banner({ titulo, subtitulo, boton }) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-teal-950 via-teal-800 to-emerald-700 text-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-8 px-6 py-16 md:flex-row">
        <div className="flex-1 text-center md:text-left">
          <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-amber-300">
            Genshin Impact · Anemo
          </p>
          <h1 className="text-4xl font-extrabold md:text-6xl">{titulo}</h1>
          <p className="mt-4 max-w-xl text-lg text-teal-100">{subtitulo}</p>
          <a
            href="#personajes"
            className="mt-8 inline-block rounded-full bg-amber-400 px-8 py-3 font-bold text-teal-950 shadow-lg transition hover:scale-105 hover:bg-amber-300"
          >
            {boton}
          </a>
        </div>
        <img
          src="/images/Xiao.jpg"
          alt="Xiao"
          className="h-64 w-64 rounded-3xl border-4 border-amber-400 object-cover shadow-2xl md:h-80 md:w-80"
        />
      </div>
    </section>
  )
}

export default Banner
