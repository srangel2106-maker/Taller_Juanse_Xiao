# Xiao - Parcial

Proyecto hecho con **React + Vite + Tailwind CSS**, temática de videojuegos (Xiao, Genshin Impact).

## Componentes
- `Banner`: encabezado principal con título, descripción, botón e imagen.
- `Card`: tarjeta reutilizable (se usa 3 veces con distintos datos).
- `Libre`: selector de habilidades de Xiao con estado (`useState`).

## Ejecutar
```
npm install
npm run dev
```

## Build
```
npm run build
```

## Deploy
Publicado en Vercel: (pega aquí tu enlace)
